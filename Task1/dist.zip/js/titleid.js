var news = [
            {
                "id":"images/foxA.jpg",
                 "title":"Greenland's Viral image",
                 "desc":"AAAA:  A photo showing sled dogs wading through water ankle-deep on top of melting ice sheet in Greenland has gone viral. The picture has taken by Steffen Oslen from the Centre for Ocean and Ice at the Danish Meterological Institute shows the scale of melting ice in Greenland. Oslen said the ice sheet beneath the water was 1.2 metres thick.",
                 "shortdesc":"Viral image of greenland",
                 "shot":"Shot by Ankush Verma."
            },
            {
                "id":"images/foxB.jpg",
                 "title":"Lorem Ipsum",
                 "desc":" BBBBB: A photo showing sled dogs wading through water ankle-deep on top of melting ice sheet in Greenland has gone viral. The picture has taken by Steffen Oslen from the Centre for Ocean and Ice at the Danish Meterological Institute shows the scale of melting ice in Greenland. Oslen said the ice sheet beneath the water was 1.2 metres thick.",
                "shortdesc":"Lorem Ipsum dolor sit amet, consetcur",
                 "shot":"Shot by Ankush Verma."
            },
            {
                "id":"images/foxC.jpg",
                 "title":"Dolor sit amet,consectetur",
                 "desc":" CCCC: A photo showing sled dogs wading through water ankle-deep on top of melting ice sheet in Greenland has gone viral. The picture has taken by Steffen Oslen from the Centre for Ocean and Ice at the Danish Meterological Institute shows the scale of melting ice in Greenland. Oslen said the ice sheet beneath the water was 1.2 metres thick.",
                "shortdesc":"Lorem Ipsum dolor sit amet, consetcur",
                 "shot":"Shot by Ankush Verma."
            }
           ];